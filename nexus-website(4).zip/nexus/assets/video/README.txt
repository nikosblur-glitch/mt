PLACEHOLDER - Optional cinematic MP4 can be placed here. The current intro is pure CSS/JS/Canvas.
