/**
 * NEXUS Website — Core JavaScript
 * Cinematic intro, particles, music, interactions, counters, etc.
 */

(function () {
  "use strict";

  const cfg = window.NEXUS_CONFIG || {};

  // ===== STATE =====
  let introComplete = false;
  let musicPlaying = false;
  let audio = null;
  let logoClickCount = 0;
  let logoClickTimer = null;

  // ===== DOM REFS =====
  const intro = document.getElementById("cinematic-intro");
  const mainSite = document.getElementById("main-site");
  const enterBtn = document.getElementById("enter-nexus");
  const musicCtrl = document.getElementById("music-controller");
  const playPauseBtn = document.getElementById("music-play-pause");
  const muteBtn = document.getElementById("music-mute");
  const volumeSlider = document.getElementById("music-volume");
  const musicTitle = document.getElementById("music-title");
  const nav = document.getElementById("main-nav");
  const hamburger = document.getElementById("hamburger");
  const mobileMenu = document.getElementById("mobile-menu");
  const mobileOverlay = document.getElementById("mobile-overlay");
  const toastContainer = document.getElementById("toast-container");
  const dashboardOverlay = document.getElementById("dashboard-overlay");
  const easterOverlay = document.getElementById("easter-overlay");

  // ===== UTILS =====
  function $(sel, ctx = document) {
    return ctx.querySelector(sel);
  }
  function $$(sel, ctx = document) {
    return Array.from(ctx.querySelectorAll(sel));
  }

  function formatNumber(n) {
    return n.toLocaleString("en-US");
  }

  function showToast(message, icon = "✦") {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerHTML = `<span class="toast-icon">${icon}</span><span>${message}</span>`;
    toastContainer.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("show"));
    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  }

  // ===== CINEMATIC INTRO =====
  function initIntro() {
    if (!intro || !enterBtn) return;

    // Intro particles
    const canvas = document.getElementById("intro-particles");
    if (canvas) {
      const ctx = canvas.getContext("2d");
      let particles = [];
      let animId;

      function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
      resize();
      window.addEventListener("resize", resize);

      for (let i = 0; i < 80; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          r: Math.random() * 2 + 0.5,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          alpha: Math.random() * 0.6 + 0.2,
        });
      }

      function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach((p) => {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
          if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(230, 0, 46, ${p.alpha})`;
          ctx.fill();
        });
        animId = requestAnimationFrame(draw);
      }
      draw();

      // Stop intro particles when done
      window._stopIntroParticles = () => cancelAnimationFrame(animId);
    }

    enterBtn.addEventListener("click", () => {
      enterNexus();
    });

    // Allow Enter key
    document.addEventListener("keydown", (e) => {
      if (!introComplete && (e.key === "Enter" || e.key === " ")) {
        e.preventDefault();
        enterNexus();
      }
    });
  }

  function enterNexus() {
    if (introComplete) return;
    introComplete = true;
    document.body.classList.remove("intro-active");

    // Start music (user gesture)
    initMusic();
    playMusic();

    // Fade intro
    intro.classList.add("hidden");
    if (window._stopIntroParticles) window._stopIntroParticles();

    // Show main site
    setTimeout(() => {
      mainSite.classList.add("visible");
      musicCtrl.classList.add("visible");
      showToast("Welcome to NEXUS", "✦");
      initMainParticles();
      initScrollReveal();
      initCounters();
      initCountdowns();
    }, 600);
  }

  // ===== MUSIC =====
  function initMusic() {
    if (audio) return;
    audio = new Audio(cfg.music?.src || "./assets/audio/nexus-ambient.mp3");
    audio.loop = true;
    audio.volume = 0;
    audio.preload = "auto";

    // Handle missing file gracefully
    audio.addEventListener("error", () => {
      console.warn("NEXUS: Ambient track not found. Place your MP3 at assets/audio/nexus-ambient.mp3");
      if (musicTitle) musicTitle.textContent = "No track (add MP3)";
    });

    if (musicTitle) musicTitle.textContent = cfg.music?.title || "NEXUS Ambient";

    if (volumeSlider) {
      volumeSlider.value = (cfg.music?.volume || 0.35) * 100;
      volumeSlider.addEventListener("input", () => {
        if (audio) audio.volume = volumeSlider.value / 100;
      });
    }

    if (playPauseBtn) {
      playPauseBtn.addEventListener("click", () => {
        if (musicPlaying) pauseMusic();
        else playMusic();
      });
    }

    if (muteBtn) {
      muteBtn.addEventListener("click", () => {
        if (!audio) return;
        if (audio.volume > 0) {
          audio.dataset.prevVol = audio.volume;
          audio.volume = 0;
          muteBtn.textContent = "🔇";
        } else {
          audio.volume = parseFloat(audio.dataset.prevVol || cfg.music?.volume || 0.35);
          muteBtn.textContent = "🔊";
        }
      });
    }
  }

  function playMusic() {
    if (!audio) return;
    audio.play().then(() => {
      musicPlaying = true;
      if (playPauseBtn) playPauseBtn.textContent = "❚❚";
      // Fade in
      const target = cfg.music?.volume || 0.35;
      const duration = cfg.music?.fadeInDuration || 2500;
      const start = performance.now();
      function fade(now) {
        const t = Math.min(1, (now - start) / duration);
        audio.volume = target * t;
        if (t < 1) requestAnimationFrame(fade);
      }
      requestAnimationFrame(fade);
    }).catch((err) => {
      console.warn("Audio play blocked or failed:", err);
    });
  }

  function pauseMusic() {
    if (!audio) return;
    audio.pause();
    musicPlaying = false;
    if (playPauseBtn) playPauseBtn.textContent = "▶";
  }

  // ===== MAIN PARTICLES =====
  function initMainParticles() {
    const canvas = document.getElementById("particles-canvas");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let particles = [];
    let mouse = { x: null, y: null };
    let animId;
    const isMobile = window.matchMedia("(max-width: 768px)").matches;
    const count = isMobile ? 40 : 90;

    function resize() {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    }
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.8 + 0.4,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        alpha: Math.random() * 0.5 + 0.15,
      });
    }

    if (!isMobile) {
      canvas.parentElement.addEventListener("mousemove", (e) => {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
      });
      canvas.parentElement.addEventListener("mouseleave", () => {
        mouse.x = mouse.y = null;
      });
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        // Subtle mouse attraction
        if (mouse.x !== null) {
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            p.x += dx * 0.01;
            p.y += dy * 0.01;
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(230, 0, 46, ${p.alpha})`;
        ctx.fill();
      });

      // Connecting lines (desktop only)
      if (!isMobile) {
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const a = particles[i];
            const b = particles[j];
            const dx = a.x - b.x;
            const dy = a.y - b.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 100) {
              ctx.beginPath();
              ctx.strokeStyle = `rgba(230, 0, 46, ${0.12 * (1 - dist / 100)})`;
              ctx.lineWidth = 0.6;
              ctx.moveTo(a.x, a.y);
              ctx.lineTo(b.x, b.y);
              ctx.stroke();
            }
          }
        }
      }

      animId = requestAnimationFrame(draw);
    }
    draw();
  }

  // ===== NAV =====
  function initNav() {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 40) nav.classList.add("scrolled");
      else nav.classList.remove("scrolled");
    });

    if (hamburger) {
      hamburger.addEventListener("click", () => {
        mobileMenu.classList.toggle("open");
        mobileOverlay.classList.toggle("open");
        document.body.style.overflow = mobileMenu.classList.contains("open") ? "hidden" : "";
      });
    }
    if (mobileOverlay) {
      mobileOverlay.addEventListener("click", () => {
        mobileMenu.classList.remove("open");
        mobileOverlay.classList.remove("open");
        document.body.style.overflow = "";
      });
    }

    // Smooth close on link click
    $$(".mobile-menu a").forEach((a) => {
      a.addEventListener("click", () => {
        mobileMenu.classList.remove("open");
        mobileOverlay.classList.remove("open");
        document.body.style.overflow = "";
      });
    });

    // Active section highlight
    const sections = $$("section[id]");
    window.addEventListener("scroll", () => {
      const scrollY = window.scrollY + 120;
      sections.forEach((sec) => {
        const top = sec.offsetTop;
        const height = sec.offsetHeight;
        const id = sec.getAttribute("id");
        const link = $(`.nav-links a[href="#${id}"]`);
        if (link) {
          if (scrollY >= top && scrollY < top + height) link.classList.add("active");
          else link.classList.remove("active");
        }
      });
    });
  }

  // ===== JOIN DISCORD =====
  function initJoinButtons() {
    const url = cfg.discord?.inviteUrl || "https://discord.gg/TzzWp7cxf";
    $$("[data-join-discord]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        window.open(url, "_blank", "noopener,noreferrer");
        showToast("Opening Discord invite…", "↗");
      });
    });
  }

  // ===== DISCORD LOGIN (architecture ready) =====
  function initAuth() {
    $$("[data-discord-login]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        // Real OAuth would redirect to Discord
        // For now we show the demo dashboard
        const clientId = cfg.discord?.clientId;
        if (clientId && clientId !== "YOUR_DISCORD_CLIENT_ID") {
          const redirect = encodeURIComponent(cfg.discord.redirectUri || window.location.origin);
          const scope = encodeURIComponent("identify guilds");
          window.location.href = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirect}&response_type=code&scope=${scope}`;
        } else {
          // Demo mode
          openDashboard();
          showToast("Demo mode — configure Discord OAuth in config/site.js", "ℹ");
        }
      });
    });

    const closeDash = $("#dashboard-close");
    if (closeDash) {
      closeDash.addEventListener("click", () => {
        dashboardOverlay.classList.remove("open");
      });
    }
    if (dashboardOverlay) {
      dashboardOverlay.addEventListener("click", (e) => {
        if (e.target === dashboardOverlay) dashboardOverlay.classList.remove("open");
      });
    }
  }

  function openDashboard() {
    const user = cfg.demoUser || {};
    const nameEl = $("#dash-display-name");
    const userEl = $("#dash-username");
    const levelEl = $("#dash-level");
    const xpEl = $("#dash-xp");
    const fill = $("#dash-xp-fill");

    if (nameEl) nameEl.textContent = user.displayName || "Member";
    if (userEl) userEl.textContent = "@" + (user.username || "user");
    if (levelEl) levelEl.textContent = user.level || 1;
    if (xpEl) xpEl.textContent = `${formatNumber(user.xp || 0)} / ${formatNumber(user.xpToNext || 1000)} XP`;
    if (fill) {
      const pct = Math.min(100, ((user.xp || 0) / (user.xpToNext || 1000)) * 100);
      fill.style.width = "0%";
      requestAnimationFrame(() => {
        fill.style.width = pct + "%";
      });
    }
    dashboardOverlay.classList.add("open");
  }

  // ===== COUNTERS =====
  function initCounters() {
    const stats = cfg.stats || {};
    const elements = {
      members: $("#stat-members"),
      online: $("#stat-online"),
      boosts: $("#stat-boosts"),
      level: $("#stat-server-level"),
      events: $("#stat-events"),
      giveaways: $("#stat-giveaways"),
      rating: $("#stat-rating"),
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateValue(elements.members, 0, stats.members || 0, 2000);
            animateValue(elements.online, 0, stats.online || 0, 1800);
            animateValue(elements.boosts, 0, stats.boosts || 0, 1500);
            animateValue(elements.level, 0, stats.serverLevel || 0, 1200);
            animateValue(elements.events, 0, stats.events || 0, 1400);
            animateValue(elements.giveaways, 0, stats.giveaways || 0, 1600);
            if (elements.rating) {
              animateValue(elements.rating, 0, stats.rating || 0, 1500, 1);
            }
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );

    const section = $("#stats");
    if (section) observer.observe(section);
  }

  function animateValue(el, start, end, duration, decimals = 0) {
    if (!el) return;
    const startTime = performance.now();
    function update(now) {
      const t = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const val = start + (end - start) * eased;
      el.textContent = decimals > 0 ? val.toFixed(decimals) : formatNumber(Math.floor(val));
      if (t < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  // ===== COUNTDOWNS =====
  function initCountdowns() {
    function update() {
      $$("[data-countdown]").forEach((el) => {
        const end = parseInt(el.dataset.countdown, 10);
        const diff = end - Date.now();
        if (diff <= 0) {
          el.textContent = "Ended";
          return;
        }
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        el.textContent = d > 0 ? `${d}d ${h}h ${m}m` : `${h}h ${m}m ${s}s`;
      });
    }
    update();
    setInterval(update, 1000);
  }

  // ===== ACCORDION =====
  function initAccordions() {
    $$(".accordion-header").forEach((btn) => {
      btn.addEventListener("click", () => {
        const item = btn.closest(".accordion-item");
        const wasOpen = item.classList.contains("open");
        // Close siblings
        item.parentElement.querySelectorAll(".accordion-item").forEach((i) => i.classList.remove("open"));
        if (!wasOpen) item.classList.add("open");
      });
    });
  }

  // ===== SCROLL REVEAL =====
  function initScrollReveal() {
    const els = $$(".reveal");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    els.forEach((el) => observer.observe(el));
  }

  // ===== EASTER EGG =====
  function initEasterEgg() {
    const logos = $$("[data-easter-logo]");
    logos.forEach((logo) => {
      logo.addEventListener("click", () => {
        logoClickCount++;
        clearTimeout(logoClickTimer);
        logoClickTimer = setTimeout(() => {
          logoClickCount = 0;
        }, 2500);
        if (logoClickCount >= 5) {
          logoClickCount = 0;
          triggerEasterEgg();
        }
      });
    });
  }

  function triggerEasterEgg() {
    if (!easterOverlay) return;
    easterOverlay.classList.add("active");
    showToast("You found the secret…", "✦");
    setTimeout(() => {
      easterOverlay.classList.remove("active");
    }, 3500);
  }

  // ===== RENDER DYNAMIC CONTENT =====
  function renderContent() {
    // Giveaways
    const giveawaysEl = $("#giveaways-grid");
    if (giveawaysEl && cfg.giveaways) {
      giveawaysEl.innerHTML = cfg.giveaways
        .map(
          (g) => `
        <div class="card reveal">
          <h3 class="card-title">${g.prize}</h3>
          <p class="card-desc">${g.description}</p>
          <div class="card-meta">
            <span>👥 ${formatNumber(g.participants)} entered</span>
            <span>🏆 ${g.winners} winner${g.winners > 1 ? "s" : ""}</span>
            <span class="countdown" data-countdown="${g.endsAt}">—</span>
          </div>
          ${g.isDemo ? '<span class="demo-badge">DEMO</span>' : ""}
          <button class="btn btn-primary" style="width:100%;margin-top:0.8rem" data-join-discord>Enter Giveaway</button>
        </div>`
        )
        .join("");
    }

    // Events
    const eventsEl = $("#events-grid");
    if (eventsEl && cfg.events) {
      eventsEl.innerHTML = cfg.events
        .map(
          (e) => `
        <div class="card reveal">
          <h3 class="card-title">${e.name}</h3>
          <p class="card-desc">${e.description}</p>
          <div class="card-meta">
            <span>📅 ${e.date}</span>
            <span>🕐 ${e.time}</span>
            <span class="countdown" data-countdown="${e.endsAt}">—</span>
          </div>
          <button class="btn btn-outline" style="width:100%;margin-top:0.8rem" data-join-discord>Join Event</button>
        </div>`
        )
        .join("");
    }

    // Rewards
    const rewardsEl = $("#rewards-grid");
    if (rewardsEl && cfg.rewards) {
      rewardsEl.innerHTML = cfg.rewards
        .map(
          (r) => `
        <div class="reward-card ${r.unlocked ? "unlocked" : "locked"} reveal">
          <div class="reward-level">${r.level}</div>
          <div class="reward-info">
            <h4>${r.title}</h4>
            <p>${r.description}</p>
          </div>
        </div>`
        )
        .join("");
    }

    // Team
    const teamEl = $("#team-grid");
    if (teamEl && cfg.team) {
      teamEl.innerHTML = cfg.team
        .map(
          (m) => `
        <div class="team-card reveal">
          <div class="team-avatar">${(m.username || "?")[0]}</div>
          <div class="team-role">${m.role}</div>
          <div class="team-name">${m.username}</div>
          <p class="team-desc">${m.description}</p>
        </div>`
        )
        .join("");
    }

    // Partners
    const partnersEl = $("#partners-grid");
    if (partnersEl && cfg.partners) {
      partnersEl.innerHTML = cfg.partners
        .map(
          (p) => `
        <div class="partner-card reveal">
          <div class="partner-logo-placeholder">${(p.name || "?")[0]}</div>
          <h4 style="margin-bottom:0.4rem">${p.name}</h4>
          <p style="font-size:0.85rem;color:var(--nx-text-muted)">${p.description}</p>
        </div>`
        )
        .join("");
    }

    // Features
    const featuresEl = $("#features-grid");
    if (featuresEl && cfg.features) {
      const icons = {
        users: "👥",
        calendar: "📅",
        gift: "🎁",
        "trending-up": "📈",
        handshake: "🤝",
        "life-buoy": "🛟",
        ticket: "🎫",
        bot: "🤖",
        mic: "🎙️",
        award: "🏆",
      };
      featuresEl.innerHTML = cfg.features
        .map(
          (f) => `
        <div class="feature-card reveal">
          <div class="feature-icon">${icons[f.icon] || "✦"}</div>
          <h3>${f.title}</h3>
          <p>${f.description}</p>
        </div>`
        )
        .join("");
    }

    // Rules
    const rulesEl = $("#rules-accordion");
    if (rulesEl && cfg.rules) {
      rulesEl.innerHTML = cfg.rules
        .map(
          (r) => `
        <div class="accordion-item">
          <button class="accordion-header">
            <span><span class="accordion-num">${r.id}</span>${r.title}</span>
            <span class="accordion-icon">+</span>
          </button>
          <div class="accordion-body">${r.content}</div>
        </div>`
        )
        .join("");
    }

    // FAQ
    const faqEl = $("#faq-accordion");
    if (faqEl && cfg.faq) {
      faqEl.innerHTML = cfg.faq
        .map(
          (f) => `
        <div class="accordion-item">
          <button class="accordion-header">
            <span>${f.q}</span>
            <span class="accordion-icon">+</span>
          </button>
          <div class="accordion-body">${f.a}</div>
        </div>`
        )
        .join("");
    }

    // Level panel demo
    const levelNum = $("#your-level");
    const xpText = $("#your-xp-text");
    const xpFill = $("#your-xp-fill");
    const user = cfg.demoUser || {};
    if (levelNum) levelNum.textContent = user.level || 27;
    if (xpText) xpText.textContent = `${formatNumber(user.xp || 2450)} / ${formatNumber(user.xpToNext || 3000)} XP`;
    if (xpFill) {
      const pct = Math.min(100, ((user.xp || 2450) / (user.xpToNext || 3000)) * 100);
      setTimeout(() => {
        xpFill.style.width = pct + "%";
      }, 500);
    }

    // Demo badges for stats
    if (cfg.stats?.isDemo) {
      $$(".stat-card").forEach((c) => {
        if (!c.querySelector(".demo-badge")) {
          const badge = document.createElement("span");
          badge.className = "demo-badge";
          badge.textContent = "DEMO DATA";
          c.appendChild(badge);
        }
      });
    }

    // Status bar online count
    const statusOnline = $("#status-online-count");
    if (statusOnline && cfg.stats) {
      statusOnline.textContent = formatNumber(cfg.stats.online || 0) + " Members Online";
    }
  }

  // ===== INIT =====
  function init() {
    document.body.classList.add("intro-active");
    renderContent();
    initIntro();
    initNav();
    initJoinButtons();
    initAuth();
    initAccordions();
    initEasterEgg();

    // Re-bind join buttons after dynamic render
    setTimeout(initJoinButtons, 100);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
