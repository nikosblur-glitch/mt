/**
 * NEXUS Website - Central Configuration
 * Edit this file to customize the entire site.
 * Discord invite, colors, content, stats, etc. all live here.
 */

const NEXUS_CONFIG = {
  // ===== BRAND =====
  brand: {
    name: "NEXUS",
    slogan: "CONNECT • CREATE • BELONG",
    description: "A next-generation Discord community built for people who want to connect, create, discover and belong.",
    logo: "./assets/images/nexus-logo.png",
    favicon: "./assets/images/nexus-logo.png",
  },

  // ===== DISCORD =====
  discord: {
    inviteUrl: "https://discord.gg/TzzWp7cxf", // ← CHANGE THIS ONLY HERE
    // OAuth2 (add your real credentials in a .env / backend, NEVER expose secrets in frontend)
    clientId: "YOUR_DISCORD_CLIENT_ID",
    redirectUri: "http://localhost:3000/auth/callback", // or your production URL
    // Note: Full OAuth requires a backend. See README for architecture.
  },

  // ===== COLORS (from logo analysis) =====
  colors: {
    primary: "#E6002E",       // Deep crimson red from logo
    primaryGlow: "#FF1A4B",
    secondary: "#C0C0C0",     // Silver from the X
    accent: "#FF4D6A",
    background: "#050505",
    surface: "#0D0D0D",
    surfaceLight: "#161616",
    text: "#FFFFFF",
    textMuted: "#A0A0A0",
    success: "#00E676",
    warning: "#FFB300",
  },

  // ===== MUSIC =====
  music: {
    src: "./assets/audio/nexus-ambient.mp3", // ← Replace with your track
    title: "NEXUS Ambient",
    volume: 0.35,
    fadeInDuration: 2500,
  },

  // ===== DEMO STATISTICS (clearly marked as demo) =====
  // Replace with real Discord API data later
  stats: {
    members: 12847,
    online: 2341,
    boosts: 87,
    serverLevel: 3,
    events: 24,
    giveaways: 156,
    rating: 4.9,
    isDemo: true, // ← set to false when live data is connected
  },

  // ===== DEMO GIVEAWAYS =====
  giveaways: [
    {
      id: 1,
      prize: "€10 Gift Card",
      description: "Win a €10 digital gift card of your choice.",
      endsAt: Date.now() + 2 * 24 * 60 * 60 * 1000, // 2 days
      participants: 342,
      winners: 1,
      image: null,
      isDemo: true,
    },
    {
      id: 2,
      prize: "NEXUS Premium Role",
      description: "Exclusive premium role with special perks.",
      endsAt: Date.now() + 5 * 24 * 60 * 60 * 1000,
      participants: 891,
      winners: 5,
      image: null,
      isDemo: true,
    },
    {
      id: 3,
      prize: "Exclusive Community Reward",
      description: "Limited edition digital reward + shoutout.",
      endsAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
      participants: 1204,
      winners: 3,
      image: null,
      isDemo: true,
    },
  ],

  // ===== REWARDS / LEVEL SYSTEM =====
  rewards: [
    { level: 5, title: "Starter Reward", description: "Welcome pack & access to starter channels", unlocked: true },
    { level: 10, title: "Active Member", description: "Custom role color & priority support", unlocked: true },
    { level: 25, title: "Veteran", description: "Exclusive veteran badge & private lounge", unlocked: true },
    { level: 30, title: "Exclusive Reward", description: "Special giveaway entry boost", unlocked: false },
    { level: 50, title: "Elite", description: "Elite role, custom emotes & voice priority", unlocked: false },
    { level: 100, title: "NEXUS LEGEND", description: "Legendary status, permanent perks & hall of fame", unlocked: false },
  ],

  // ===== DEMO USER (for dashboard preview) =====
  demoUser: {
    username: "NEXUS_Member",
    displayName: "Alex",
    avatar: null, // will use placeholder
    level: 27,
    xp: 2450,
    xpToNext: 3000,
    id: "000000000000000000",
  },

  // ===== EVENTS =====
  events: [
    {
      id: 1,
      name: "NEXUS Community Night",
      date: "2026-08-22",
      time: "20:00 UTC",
      description: "Hang out, play games and meet new members. Prizes for winners!",
      image: null,
      endsAt: Date.now() + 5 * 24 * 60 * 60 * 1000,
    },
    {
      id: 2,
      name: "Creator Showcase",
      date: "2026-08-28",
      time: "18:00 UTC",
      description: "Share your projects, art, music or code. Feedback from the community.",
      image: null,
      endsAt: Date.now() + 11 * 24 * 60 * 60 * 1000,
    },
    {
      id: 3,
      name: "Monthly Giveaway Finals",
      date: "2026-09-05",
      time: "21:00 UTC",
      description: "The biggest giveaways of the month. Don't miss it.",
      image: null,
      endsAt: Date.now() + 19 * 24 * 60 * 60 * 1000,
    },
  ],

  // ===== TEAM =====
  team: [
    {
      username: "NexusFounder",
      role: "Founder & Lead",
      description: "Building the future of community.",
      avatar: null,
      socials: { twitter: "#", discord: "#" },
    },
    {
      username: "VoidAdmin",
      role: "Community Manager",
      description: "Keeping NEXUS welcoming and active.",
      avatar: null,
      socials: { twitter: "#", discord: "#" },
    },
    {
      username: "PixelMod",
      role: "Moderator",
      description: "Enforcing rules with fairness.",
      avatar: null,
      socials: { twitter: "#", discord: "#" },
    },
    {
      username: "EchoDev",
      role: "Bot Developer",
      description: "Crafting the tools that power NEXUS.",
      avatar: null,
      socials: { twitter: "#", discord: "#" },
    },
  ],

  // ===== PARTNERS =====
  partners: [
    { name: "Partner Community A", description: "Allied Discord community", logo: null, website: "#", discord: "#" },
    { name: "Partner Community B", description: "Collaborative events partner", logo: null, website: "#", discord: "#" },
    { name: "Creator Collective", description: "Supporting creators together", logo: null, website: "#", discord: "#" },
  ],

  // ===== FEATURES =====
  features: [
    { icon: "users", title: "Community", description: "Meet new people and build lasting connections." },
    { icon: "calendar", title: "Events", description: "Participate in regular community events and hangouts." },
    { icon: "gift", title: "Giveaways", description: "Take part in special rewards and exclusive giveaways." },
    { icon: "trending-up", title: "Level System", description: "Earn XP, level up and unlock unique rewards." },
    { icon: "handshake", title: "Partnerships", description: "Connect with other communities and creators." },
    { icon: "life-buoy", title: "Support", description: "Get help from the NEXUS team anytime." },
    { icon: "ticket", title: "Tickets", description: "Dedicated support system for members." },
    { icon: "bot", title: "Custom Bots", description: "Advanced community automation and tools." },
    { icon: "mic", title: "Voice", description: "High-quality community voice channels." },
    { icon: "award", title: "Rewards", description: "Unlock exclusive benefits as you grow." },
  ],

  // ===== RULES =====
  rules: [
    { id: "01", title: "Respect Everyone", content: "Treat all members with kindness and respect. No discrimination, toxicity or personal attacks." },
    { id: "02", title: "No Spam", content: "Avoid flooding channels, excessive mentions, or repetitive messages." },
    { id: "03", title: "No Harassment", content: "Harassment, bullying, or targeted negative behavior will result in immediate action." },
    { id: "04", title: "No Unauthorized Advertising", content: "Do not promote other servers, products or services without staff approval." },
    { id: "05", title: "Follow Discord Terms of Service", content: "All Discord ToS and Community Guidelines apply here as well." },
    { id: "06", title: "Keep the Community Safe", content: "Report anything that makes you or others feel unsafe. We take safety seriously." },
    { id: "07", title: "Have Fun", content: "NEXUS is here for connection, creativity and belonging. Enjoy the ride." },
  ],

  // ===== SOCIALS =====
  socials: {
    discord: "https://discord.gg/TzzWp7cxf",
    tiktok: "#",
    youtube: "#",
    instagram: "#",
    x: "https://x.com/Nikonay5",
  },

  // ===== FAQ =====
  faq: [
    { q: "What is NEXUS?", a: "NEXUS is a next-generation Discord community focused on connection, creation and belonging. We combine premium experiences, events, giveaways and a real progression system." },
    { q: "How do I join?", a: "Click any JOIN NEXUS button on this website. You’ll be taken to our Discord invite. Accept the invite and you’re in." },
    { q: "How do levels work?", a: "You earn XP by being active in the server (messages, voice, events). Level up to unlock roles, rewards and exclusive perks." },
    { q: "How do giveaways work?", a: "Enter giveaways through the designated channels or the website (when connected). Winners are selected fairly and announced." },
    { q: "How can I become staff?", a: "We open staff applications periodically. Stay active, be helpful, and watch for announcements." },
    { q: "How do I contact support?", a: "Open a support ticket in the server or reach out to any staff member. We’re here to help." },
  ],
};

// Make available globally
if (typeof window !== "undefined") {
  window.NEXUS_CONFIG = NEXUS_CONFIG;
}
