# NEXUS — Premium Discord Community Website

**CONNECT • CREATE • BELONG**

A cinematic, futuristic, production-ready website experience for the NEXUS Discord community.  
Designed to feel like a real premium digital platform / brand, not a generic Discord landing page.

---

## Quick Start

### Local static server (recommended)

```bash
# From the project root (nexus/)
npx serve .
# or
python3 -m http.server 8080
# or
npx http-server -p 8080
```

Then open: `http://localhost:8080` (or the port shown).

You can also open `index.html` directly, but a local server is preferred for audio and best compatibility.

---

## Brand & Visual Identity

The entire design is derived from the official NEXUS logo:

- Primary crimson / red (`#E6002E` / `#FF1A4B`)
- Silver / metallic accents from the “X”
- Pure dark background (`#050505`)
- Glowing effects, circular geometry, premium typography

Colors are defined in `css/main.css` (`:root`) and mirrored in `config/site.js`.

---

## Central Configuration

**Everything important lives in one file:**

```
config/site.js
```

Edit this single file to change:

| Setting              | Key                     |
|----------------------|-------------------------|
| Discord invite       | `discord.inviteUrl`     |
| Brand name / slogan  | `brand.*`               |
| Colors               | `colors.*`              |
| Statistics (demo)    | `stats.*`               |
| Giveaways            | `giveaways[]`           |
| Rewards / levels     | `rewards[]`             |
| Events               | `events[]`              |
| Team members         | `team[]`                |
| Partners             | `partners[]`            |
| Features             | `features[]`            |
| Rules                | `rules[]`               |
| FAQ                  | `faq[]`                 |
| Social links         | `socials.*`             |
| Music settings       | `music.*`               |
| Demo user (dashboard)| `demoUser.*`            |

**Discord invite is already set to:**  
`https://discord.gg/TzzWp7cxf`

Change it only in `config/site.js` → `discord.inviteUrl`. All JOIN NEXUS buttons use this value.

---

## Cinematic Intro

On first load the user sees a full-screen cinematic experience:

1. Logo reveal with glow + ring animation  
2. “WELCOME TO NEXUS”  
3. Slogan  
4. Large **▶ ENTER NEXUS** button  

Clicking the button (or pressing Enter / Space):

- Starts background music (user-gesture compliant)  
- Fades out the intro  
- Reveals the main website  
- Activates particle systems and interactions  

---

## Background Music

Placeholder path:

```
assets/audio/nexus-ambient.mp3
```

Replace this file with any **royalty-free** chill / futuristic / ambient track (loopable recommended).

The floating music controller supports Play/Pause, Mute, Volume and smooth fade-in.

---

## Discord Login (OAuth2 Architecture)

The site includes a complete architecture for Discord OAuth2:

1. Keep secrets in a backend / environment variables only:
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `DISCORD_REDIRECT_URI`

2. In `config/site.js` set a real `clientId` and `redirectUri`.

3. When a real clientId is present, the LOGIN button redirects to Discord’s authorize endpoint.

4. You still need a small backend to exchange the code, fetch the user, and create a secure session.

Until credentials are added, the login button opens a **demo dashboard** so you can preview the UX.

Never expose the Client Secret in frontend code.

---

## Demo vs Live Data

All statistics, giveaways, events, rewards and the user dashboard are clearly marked as **DEMO** content.

When you connect real Discord API / bot data, simply replace the arrays and numbers in `config/site.js` (or fetch them from your API). The UI is already ready for live data.

---

## Features Implemented

- Full-screen cinematic intro with logo animation
- Particle systems (intro + hero) with mouse interaction
- Premium sticky glass navigation + mobile hamburger
- Hero with logo, slogan, dual CTAs
- Live status bar
- Animated statistics counters
- Feature grid
- Level / XP progress system
- Giveaways with live countdown
- Rewards with locked/unlocked states
- Events with countdown
- Team cards
- Partners
- Rules accordion
- FAQ accordion
- Social links
- Floating music controller
- Toast notification system
- Demo user dashboard
- Easter egg (click logo 5 times)
- Full responsive design
- prefers-reduced-motion support
- Accessibility basics (semantic HTML, ARIA, keyboard)
- Central config system
- Discord invite single source of truth

---

## Project Structure

```
nexus/
├── index.html
├── README.md
├── config/
│   └── site.js             ★ Central configuration
├── css/
│   └── main.css
├── js/
│   └── main.js
└── assets/
    ├── images/
    │   └── nexus-logo.png
    ├── audio/
    │   ├── nexus-ambient.mp3   ← Replace with your track
    │   └── README.txt
    └── video/
        └── README.txt
```

---

## Deployment

Any static host works:

- Vercel / Netlify / Cloudflare Pages
- GitHub Pages
- Traditional web hosting

For full Discord OAuth you will need at least one serverless function or small Node backend.

---

## Notes

- Use only royalty-free music.
- The empty `nexus-ambient.mp3` is a placeholder so the path is valid.
- All “DEMO” badges are intentional until you connect real data.
- The logo click easter egg triggers a special message after 5 clicks.

---

**NEXUS is not just a server.**  
**NEXUS is a world.**

✦ CONNECT • CREATE • BELONG ✦
